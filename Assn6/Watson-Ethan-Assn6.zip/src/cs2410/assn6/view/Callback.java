package cs2410.assn6.view;

/**
 * Interface for a basic callback
 *
 * @author Ethan Watson
 * @version X.X.X
 */
public interface Callback {
    void callback(DisplayOption screen);
}
